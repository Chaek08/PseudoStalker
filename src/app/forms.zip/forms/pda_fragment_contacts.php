<?php
namespace app\forms;

use php\gui\UXImage;
use std, gui, framework, app;
use php\gui\event\UXWindowEvent; 


class pda_fragment_contacts extends AbstractForm
{
    private $localization;

    public function __construct() 
    {
        parent::__construct();

        $this->localization = new Localization($language);
    }
    
    function getCurrentLanguageFromUI()
    {
        return $this->form('Client')->MainMenu->content->Options->content->Language_Switcher_Combobobx->value;
    }    
    
    function UpdateData()
    {
        $name = trim($this->form('Client')->Pda->content->SDK_EnemyName);
        $icon = trim($this->form('Client')->Pda->content->SDK_EnemyIcon);
        $bio = trim($this->form('Client')->Pda->content->SDK_EnemyBio);
        
        $role_name = trim($this->form('Client')->Pda->content->SDK_PidoRoleName);
        $role_icon = trim($this->form('Client')->Pda->content->SDK_PidoRoleIcon);
        $role_color = trim($this->form('Client')->Pda->content->SDK_PidoRoleColor);
        
        $this->localization->setLanguage($this->getCurrentLanguageFromUI());        
        
        $this->name->text = $name !== '' ? $name : $this->localization->get('Enemy_Name');
        $this->icon->image = new UXImage($icon !== '' ? $icon : 'res://.data/ui/icon_npc/goblindav.png');
        $this->bio->text = $bio !== '' ? $bio : $this->localization->get('GoblindaV_Bio');
        
        $this->community->text = $role_name != '' ? $role_name : $this->localization->get('Community_Pido');
        $this->community->graphic = new UXImageView(new UXImage($role_icon != '' ? $role_icon : 'res://.data/ui/dialog/pidoras_role.png'));
        $this->community->textColor = $role_color != '' ? $role_color : '#16a4cd';
        
        ($g = $this->community->graphic)->width = ($g->height = 16);
    }    
    /**
     * @event selected_new.click-2x 
     */
    function RedirectRaiting(UXMouseEvent $e = null)
    {    
        $this->form('Client')->Pda->content->UpdateBtnColor();
        $this->form('Client')->Pda->content->ranks_label->textColor = '#d59b30';    
    
        $this->form('Client')->Pda->content->RankingBtn();
        
        $this->form('Client')->Pda->content->Pda_Ranking->content->ResetBtnColor();
        foreach (['goblindav_in_raiting_pos', 'goblindav_in_raiting_name', 'goblindav_in_raiting_rank'] as $labelName)
        {
            $this->form('Client')->Pda->content->Pda_Ranking->content->{$labelName}->textColor = '#cccccc';
        }        
        $this->form('Client')->Pda->content->Pda_Ranking->content->EnemyInListBtn();        
    }
    function setCharacterSelected($selected)
    {
        $this->selected_new->opacity = $selected ? 0.40 : 0;
               
        if ($selected)
        {
            $this->bio->show();
            
            $this->localization->setLanguage($this->getCurrentLanguageFromUI());
                        
            $this->tab_detail->text = $this->localization->get('TabBio');
        }
        else
        {
            $this->bio->hide();
            $this->tab_detail->text = null;
        }
    }
    /**
     * @event selected_new.click-Left 
     */
    function CharacterClick(UXMouseEvent $e = null)
    {
        $this->setCharacterSelected(true);
    }
    /**
     * @event frame.click-Left 
     */
    function HideCharacter(UXMouseEvent $e = null)
    {    
        $this->setCharacterSelected(false);         
    }      
    function UpdateContacts()
    {
        $elements = [
            $this->name,
            $this->community,
            $this->community_desc,
            $this->rank,
            $this->rank_desc,
            $this->relationship,
            $this->relationship_desc,
            $this->reputation,
            $this->reputation_desc,
            $this->online_icon,
            $this->icon,
            $this->selected_new
        ];

        foreach ($elements as $el)
        {
            if ($GLOBALS['EnemyFailed'])
            {
                $el->hide();
            }
            else
            {
                $el->show();
            }
        }

        $this->selected_new->opacity = 0;

        if ($this->bio->visible) 
        {
            $this->bio->hide();
            $this->tab_detail->text = null;
        } 
    }   
}
