<?php
namespace app\forms;

use php\gui\UXDialog;
use php\lang\System;
use system\DFFIType;
use system\DFFI;
use php\gui\animation\UXAnimationTimer;
use php\gui\UXImageView;
use php\gui\UXImage;
use action\Media;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXKeyEvent; 


class ui_test extends AbstractForm
{
    function BlockGladiatorAccess()
    {
        if (System::getProperty('user.name') == 'drogo')
        {
            UXDialog::show('Вам запрещён доступ к PseudoStalker. Свяжитесь с глав. разработчиком в Discord (chaek08)', 'ERROR');
            $this->form('Client')->LoadScreen->visible = true;
            $this->form('Client')->LoadScreen->content->background->text = 'Уходи отсюда мужик☠️☠️';
            $this->form('Client')->LoadScreen->content->background->graphic = new UXImageView(new UXImage('res://.data/img/tt.png'));
        }        
    }
    /**
     * @event label.mouseExit 
     */
    function LabelMouseExit(UXMouseEvent $e = null)
    {    
        $this->label->textColor = '#ffffff';
    }
    /**
     * @event label.mouseEnter 
     */
    function LabelMouseEnter(UXMouseEvent $e = null)
    {    
        $this->label->textColor = '#b3b3b3';
    }
    /**
     * @event label.mouseDown-Left 
     */
    function LabelMouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->label->textColor = '#808080'; 
    }
    /**
     * @event label.mouseUp-Left 
     */
    function LabelMouseUpLeft(UXMouseEvent $e = null)
    {    
        $this->LabelMouseExit();
        $this->LabelMouseEnter();
    }

    /**
     * @event btn_legacy.click-Left 
     */
    function doBtn_legacyClickLeft(UXMouseEvent $e = null)
    {

    }

    /**
     * @event edit.globalKeyDown-Enter 
     */
    function doEditGlobalKeyDownEnter(UXKeyEvent $e = null)
    {    
        $this->label->text = $this->edit->text;
    }

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        $this->health_bar_gg->hide();
        $this->health_bar_gg_b->hide();
        
        $this->health_static_gg->graphic = new UXImageView(new UXImage('res://.data/ui/maingame/skull_new.png'));
    }

    /**
     * @event button3.click-Left 
     */
    function doButton3ClickLeft(UXMouseEvent $e = null)
    {    
        $this->health_bar_gg->show();
        $this->health_bar_gg_b->show();
        
        $this->health_static_gg->graphic = null;
    }

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null)
    {    
        $this->animateResizeWidth($this->health_bar_gg, -50); 
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
        $this->animateResizeWidth($this->health_bar_gg, 50);
    }

    /**
     * @event button6.click-Left 
     */
    function doButton6ClickLeft(UXMouseEvent $e = null)
    {    
    $image = new UXImage("res://.data/ui/Inv_Vodka.png");
    $imageView = new UXImageView($image);


    $imageView->preserveRatio = true;
    $imageView->smooth = true; // красиво рендерит

    // Размеры кнопки
    $buttonWidth = $this->button6->width;
    $buttonHeight = $this->button6->height;

    // Размеры изображения
    $originalWidth = 525;
    $originalHeight = 1486;

    // Масштаб, чтобы вписать в кнопку
    $scale = min($buttonWidth / $originalWidth, $buttonHeight / $originalHeight);

    // Применяем реальные размеры
    $imageView->width = $originalWidth * $scale;
    $imageView->height = $originalHeight * $scale;

    // Центрируем вручную, если нужно
    $imageView->translateX = ($buttonWidth - $imageView->width) / 2;
    $imageView->translateY = ($buttonHeight - $imageView->height) / 2;

    // Вставляем в кнопку
    $this->button6->graphic = $imageView;
    }
    
    private $isAnimating = false;    
    
    function animateResizeWidth($node, $delta, $speed = 2)
    {
        if ($this->isAnimating)
        {
            return;
        }

        $this->isAnimating = true;
    
        $targetWidth = $node->width + $delta;

        $timer = new UXAnimationTimer(function () use ($node, $targetWidth, $speed, &$timer) {
            if ($node->width < $targetWidth) 
            {
                $node->width += $speed;
            }
            elseif ($node->width > $targetWidth)
            {
                $node->width -= $speed;
            }

            if ($node->width <= $targetWidth && $node->width >= $targetWidth)
            {
                $node->width = $targetWidth;
                $timer->stop();
                $this->isAnimating = false;
            }
        });

        $timer->start();
    } 
}
